package Alinhamento;

use 5.012000;
use strict;
use warnings;


require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use Alinhamento ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(

) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
);

our $VERSION = '0.01';


my $diagonal = 0;
my $vertical = 1;
my $horizontal = 2;
my $parar = -1;


sub new{
	my ($class,%args) = @_;
	my $self = {};
	$self->{s1} = $args{s1} if exists $args{s1};
	$self->{s2} = $args{s2} if exists $args{s2};
	$self->{align} = $args{align} if exists $args{align};

	if (exists $args{scoring}){
		$self->{scoring} = $args{scoring};
	}else{
		$self->{scoring} = \&scoring;
	}

	if (exists $args{espaco}){
		$self->{espaco} = $args{espaco}*-1;
	}else{
		$self->{espaco} = -4;
	}

	bless $self,$class;

}

sub scoring{
	my ($a,$b) = @_;
	return 1 if $a eq $b;
	return -1;
}

sub autoload{

	my $self = shift;
	my @matriz;
	my %alinhamentos;

	$matriz[0][0]{score}=0;
	$matriz[0][0]{escolha}=$parar;

	for (my $i = 1; $i <= length($self->{s2}); $i++) {
		$matriz[$i][0]{score} = $self->{espaco}*$i;
		$matriz[$i][0]{escolha}=$horizontal;
	}

	for (my $j = 1; $j <= length($self->{s1}); $j++) {
		$matriz[0][$j]{score} = $self->{espaco}*$j;
		$matriz[0][$j]{escolha}=$vertical;

	}

	for (my $i = 1; $i <= length($self->{s2}); $i++) {
		for (my $j = 1; $j <= length($self->{s1}); $j++) {

			my ($score_vertical,$score_horizontal,$score_diagonal);
			my $char1 = substr($self->{s1}, $j-1, 1);
			my $char2 = substr($self->{s2}, $i-1, 1);

			$score_diagonal = $matriz[$i-1][$j-1]{score} + &{$self->{scoring}}($char1,$char2);
			$score_horizontal = $matriz[$i-1][$j]{score} + $self->{espaco};
			$score_vertical = $matriz[$i][$j-1]{score} + $self->{espaco};


			if($score_diagonal >= $score_vertical and $score_diagonal >= $score_horizontal){
				$matriz[$i][$j]{score} = $score_diagonal;
				$matriz[$i][$j]{escolha} = $diagonal
			}elsif ($score_vertical >=$score_diagonal and $score_vertical >= $score_horizontal ){
				$matriz[$i][$j]{score} = $score_vertical;
				$matriz[$i][$j]{escolha} = $vertical
			}else{
				$matriz[$i][$j]{score} = $score_horizontal;
				$matriz[$i][$j]{escolha} = $horizontal;
			}
		}
	}

	my $i = length($self->{s2});
	my $j = length($self->{s1});

	$alinhamentos{s1}="";
	$alinhamentos{s2}="";
	$alinhamentos{score} = $matriz[$i][$j]{score};

	until ($matriz[$i][$j]{escolha} eq $parar){
		if($matriz[$i][$j]{escolha} eq $diagonal){
			$alinhamentos{s1} .= substr($self->{s1},$j-1,1);
			$alinhamentos{s2} .= substr($self->{s2},$i-1,1);
			$i--;
			$j--;
		}elsif ($matriz[$i][$j]{escolha} eq $vertical){
			$alinhamentos{s1} .= substr($self->{s1},$j-1,1);
			$alinhamentos{s2} .= '-';
			$j--;
		}else{
			$alinhamentos{s1} .= '-';
			$alinhamentos{s2} .= substr($self->{s2},$i-1,1);
			$i--;
		}
	}

	$alinhamentos{s1} = reverse $alinhamentos{s1};
	$alinhamentos{s2} = reverse $alinhamentos{s2};
	return %alinhamentos;
}

sub get_alin1{
	my $self = shift;
	my %autoload_result = $self->autoload();
	return $autoload_result{s1};
}


sub get_alin2{
	my $self = shift;
	my %autoload_result = $self->autoload();
	return $autoload_result{s2};
}

sub get_score{
	my $self = shift;
	my %autoload_result = $self->autoload();
	return $autoload_result{score};
}

sub print{
	my $self = shift;
	printf "s1: %s\ns2: %s\tscore: %3d\n\n", $self->get_alin1, $self->get_alin2, $self->get_score;
	return $self;
}

















# Preloaded methods go here.

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

Alinhamento - Perl extension for blah blah blah

=head1 SYNOPSIS

  use Alinhamento;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for Alinhamento, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Ricardo  Branco, E<lt>ricardobranco@apple.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2013 by Ricardo  Branco

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.16.2 or,
at your option, any later version of Perl 5 you may have available.


=cut
