package Alinhamento;

use 5.012000;
use strict;
use warnings;
use String::KeyboardDistance qw(:all);


require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use Alinhamento ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(

) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(&calculaAlinhamento
);

our $VERSION = '0.01';


my $diagonal = 0;
my $vertical = 1;
my $horizontal = 2;
my $parar = -1;

my $score_espaco = -4;
my $score_igual = 4;
my $score_teclado = 2;
my $score_diferente = -1;




sub calculaAlinhamento {

	my ($palavra1,$palavra2) = @_;
	my @matriz;
	my %alinhamentos;

	$matriz[0][0]{score}=0;
	$matriz[0][0]{escolha}=$parar;

	for (my $i = 1; $i <= length($palavra2); $i++) {
		$matriz[$i][0]{score} = $score_espaco*$i;
		$matriz[$i][0]{escolha}=$horizontal;
	}

	for (my $j = 1; $j <= length($palavra1); $j++) {
		$matriz[0][$j]{score} = $score_espaco*$j;
		$matriz[0][$j]{escolha}=$vertical;

	}

	for (my $i = 1; $i <= length($palavra2); $i++) {
		for (my $j = 1; $j <= length($palavra1); $j++) {

			my ($score_vertical,$score_horizontal,$score_diagonal);
			my $char1 = substr($palavra1, $j-1, 1);
			my $char2 = substr($palavra2, $i-1, 1);

			my $distancia = qwerty_char_distance($char1,$char2);


			if($distancia eq 0){
				$score_diagonal = $matriz[$i-1][$j-1]{score} + $score_igual;
			} elsif ($distancia eq 1){
				$score_diagonal = $matriz[$i-1][$j-1]{score} + $score_teclado;
			} else{
				$score_diagonal = $matriz[$i-1][$j-1]{score} + $score_diferente;
			}

			$score_horizontal = $matriz[$i-1][$j]{score} + $score_espaco;
			$score_vertical = $matriz[$i][$j-1]{score} + $score_espaco;


			if($score_diagonal >= $score_vertical and $score_diagonal >= $score_horizontal){
				$matriz[$i][$j]{score} = $score_diagonal;
				$matriz[$i][$j]{escolha} = $diagonal
			}elsif ($score_vertical >=$score_diagonal and $score_vertical >= $score_horizontal ){
				$matriz[$i][$j]{score} = $score_vertical;
				$matriz[$i][$j]{escolha} = $vertical
			}else{
				$matriz[$i][$j]{score} = $score_horizontal;
				$matriz[$i][$j]{escolha} = $horizontal;
			}
		}
	}

	my $i = length($palavra2);
	my $j = length($palavra1);

	$alinhamentos{$palavra1}="";
	$alinhamentos{$palavra2}="";
	$alinhamentos{score} = $matriz[$i][$j]{score};

	until ($matriz[$i][$j]{escolha} eq $parar){
		if($matriz[$i][$j]{escolha} eq $diagonal){
			$alinhamentos{$palavra1} .= substr($palavra1,$j-1,1);
			$alinhamentos{$palavra2} .= substr($palavra2,$i-1,1);
			$i--;
			$j--;
		}elsif ($matriz[$i][$j]{escolha} eq $vertical){
			$alinhamentos{$palavra2} .= substr($palavra1,$j-1,1);
			$alinhamentos{$palavra1} .= '-';
			$j--;
		}else{
			$alinhamentos{$palavra2} .= '-';
			$alinhamentos{$palavra1} .= substr($palavra2,$i-1,1);
			$i--;
		}
	}

	$alinhamentos{$palavra1} = reverse $alinhamentos{$palavra1};
	$alinhamentos{$palavra2} = reverse $alinhamentos{$palavra2};
	return %alinhamentos;



}







# Preloaded methods go here.

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

Alinhamento - Perl extension for blah blah blah

=head1 SYNOPSIS

  use Alinhamento;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for Alinhamento, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Ricardo  Branco, E<lt>ricardobranco@apple.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2013 by Ricardo  Branco

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.16.2 or,
at your option, any later version of Perl 5 you may have available.


=cut
